function Login() {
    return (
      <>
          <h1>Giriş Yap</h1>
      </>
    );
  }
  
  export default Login;
  