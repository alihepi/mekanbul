import Header from "./Header";
import InputWithLabel from "./InputWithLabel";
import "bootstrap"
import { useLocation } from "react-router-dom";


function AddUpdateVenue() {

  const { state } = useLocation();
  const venue = state?.venue || {};

  const Guncelle = () => {
    return (
      <>
        <Header
          headerText={venue.name + " Mekanını Güncelle"}
          motto=""
        />
        <InputWithLabel label={"Mekan Adı"} value={venue.name}/>
        <InputWithLabel label={"Mekan Adresi"} value={venue.address}/>
        <InputWithLabel label={"İmkanlar"} value={venue.foodanddrink}/>
        <InputWithLabel label={"Enlem"} value={venue.coordinates[0]}/>
        <InputWithLabel label={"Boylam"} value={venue.coordinates[1]}/>
        <InputWithLabel label={"Günler-1"} value={venue.hours[0].days}/>
        <InputWithLabel label={"Açılış-1"} value={venue.hours[0].open}/>
        <InputWithLabel label={"Kapanış-1"} value={venue.hours[0].close}/>
        <InputWithLabel label={"Kapalı"} type={"checkbox"} />
        <InputWithLabel label={"Günler-2"} value={venue.hours[1].days}/>
        <InputWithLabel label={"Açılış-2"} value={venue.hours[1].open}/>
        <InputWithLabel label={"Kapanış-2"} value={venue.hours[1].close}/>
        <InputWithLabel label={"Kapalı-2"} type={"checkbox"} />

      </>
    );
  }

  const Yeni = () => {
    return (
      <>
        <Header
          headerText={"Yeni Mekan Ekle"}
          motto=""
        />
        <InputWithLabel label={"Mekan Adı"} />
        <InputWithLabel label={"Mekan Adresi"} />
        <InputWithLabel label={"İmkanlar"} />
        <InputWithLabel label={"Enlem"} />
        <InputWithLabel label={"Boylam"} />
        <InputWithLabel label={"Günler-1"} />
        <InputWithLabel label={"Açılış-1"} />
        <InputWithLabel label={"Kapanış-1"} />
        <InputWithLabel label={"Kapalı"} type={"checkbox"} />
        <InputWithLabel label={"Günler-2"} />
        <InputWithLabel label={"Açılış-2"} />
        <InputWithLabel label={"Kapanış-2"} />
        <InputWithLabel label={"Kapalı-2"} type={"checkbox"} />
      </>
    );
  }

  return (
    <>
      {venue.id ?
        (
          <Guncelle/>
        ) : (
          <Yeni/>
        )}
    </>
  );
}

export default AddUpdateVenue;
