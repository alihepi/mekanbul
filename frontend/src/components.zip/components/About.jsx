import Header from "./Header";
function About() {
  return (
    <div>
      <Header
        headerText="Mekanbul"
        motto="ReactJS Single Page Application (SPA)"
      />
    </div>
  );
}
export default About;
