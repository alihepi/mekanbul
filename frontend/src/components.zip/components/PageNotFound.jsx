import Header from "./Header";
function PageNotFound() {
  return (
    <div>
      <Header headerText="Hata" motto="Sayfa Bulunamadı!" />
    </div>
  );
}
export default PageNotFound;
