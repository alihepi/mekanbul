function Footer() {
  return (
    <footer>
      <small>&copy; Asım Sinan Yüksel 2023</small>{" "}
    </footer>
  );
}
export default Footer;
