import React from "react";
import '../App.css'

const InputWithLabel = ({
    id,
    label,
    value,
    type,
    onInputChange,
    isFocused,
    className
  }) => {
    const inputRef = React.useRef();
    React.useEffect(() => {
      if (isFocused && inputRef.current) {
        inputRef.current.focus();
      }
    }, [isFocused]);
    return (
      <div className="input-set">
        <label className="text-right" htmlFor={id}>{label}</label>&nbsp;
        <input
          id={id}
          type={type}
          value={value}
          onChange={onInputChange}
          ref={inputRef}
          className={type !== 'checkbox' ? 'my-set' : ''}
        />
      </div>
    );
  };
  export default InputWithLabel;