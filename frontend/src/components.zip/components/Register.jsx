function Register() {
    return (
      <>
          <h1>Kayıt ol</h1>
      </>
    );
  }
  
  export default Register;
  